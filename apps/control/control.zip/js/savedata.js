
var turtleXP;

function addTurtle() {

	myScore = new component("30px", "Consolas", "black", 280, 40, "text");
}






